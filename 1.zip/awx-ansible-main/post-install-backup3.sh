#!/bin/bash
cd $HOME/$CLUSTER_NAME

#Patch Default Cilium resources for CNI replacement

kubectl -n kube-system annotate serviceaccount cilium meta.helm.sh/release-name=cilium
kubectl -n kube-system annotate serviceaccount cilium meta.helm.sh/release-namespace=kube-system
kubectl -n kube-system label serviceaccount cilium app.kubernetes.io/managed-by=Helm
kubectl -n kube-system annotate serviceaccount cilium-operator meta.helm.sh/release-name=cilium
kubectl -n kube-system annotate serviceaccount cilium-operator meta.helm.sh/release-namespace=kube-system
kubectl -n kube-system label serviceaccount cilium-operator app.kubernetes.io/managed-by=Helm
kubectl -n kube-system annotate secret hubble-ca-secret meta.helm.sh/release-name=cilium
kubectl -n kube-system annotate secret hubble-ca-secret meta.helm.sh/release-namespace=kube-system
kubectl -n kube-system label secret hubble-ca-secret app.kubernetes.io/managed-by=Helm
kubectl -n kube-system annotate secret hubble-server-certs meta.helm.sh/release-name=cilium
kubectl -n kube-system annotate secret hubble-server-certs meta.helm.sh/release-namespace=kube-system
kubectl -n kube-system label secret hubble-server-certs app.kubernetes.io/managed-by=Helm
kubectl -n kube-system annotate configmap cilium-config meta.helm.sh/release-name=cilium
kubectl -n kube-system annotate configmap cilium-config meta.helm.sh/release-namespace=kube-system
kubectl -n kube-system label configmap cilium-config app.kubernetes.io/managed-by=Helm
kubectl -n kube-system annotate secret cilium-ca meta.helm.sh/release-name=cilium
kubectl -n kube-system annotate secret cilium-ca meta.helm.sh/release-namespace=kube-system
kubectl -n kube-system label secret cilium-ca app.kubernetes.io/managed-by=Helm
kubectl -n kube-system annotate service hubble-peer meta.helm.sh/release-name=cilium
kubectl -n kube-system annotate service hubble-peer meta.helm.sh/release-namespace=kube-system
kubectl -n kube-system label service hubble-peer app.kubernetes.io/managed-by=Helm
kubectl -n kube-system annotate daemonset cilium meta.helm.sh/release-name=cilium
kubectl -n kube-system annotate daemonset cilium meta.helm.sh/release-namespace=kube-system
kubectl -n kube-system label daemonset cilium app.kubernetes.io/managed-by=Helm
kubectl -n kube-system annotate deployment cilium-operator meta.helm.sh/release-name=cilium
kubectl -n kube-system annotate deployment cilium-operator meta.helm.sh/release-namespace=kube-system
kubectl -n kube-system label deployment cilium-operator app.kubernetes.io/managed-by=Helm
kubectl annotate clusterrole cilium meta.helm.sh/release-name=cilium
kubectl annotate clusterrole cilium meta.helm.sh/release-namespace=kube-system
kubectl label clusterrole cilium app.kubernetes.io/managed-by=Helm
kubectl annotate clusterrole cilium-operator meta.helm.sh/release-name=cilium
kubectl annotate clusterrole cilium-operator meta.helm.sh/release-namespace=kube-system
kubectl label clusterrole cilium-operator app.kubernetes.io/managed-by=Helm
kubectl annotate clusterrolebinding cilium meta.helm.sh/release-name=cilium
kubectl annotate clusterrolebinding cilium meta.helm.sh/release-namespace=kube-system
kubectl label clusterrolebinding cilium app.kubernetes.io/managed-by=Helm
kubectl annotate clusterrolebinding cilium-operator meta.helm.sh/release-name=cilium
kubectl annotate clusterrolebinding cilium-operator meta.helm.sh/release-namespace=kube-system
kubectl label clusterrolebinding cilium-operator app.kubernetes.io/managed-by=Helm
kubectl annotate role cilium-config-agent -n kube-system meta.helm.sh/release-name=cilium
kubectl annotate role cilium-config-agent -n kube-system meta.helm.sh/release-namespace=kube-system
kubectl label role cilium-config-agent -n kube-system app.kubernetes.io/managed-by=Helm
kubectl annotate rolebinding cilium-config-agent -n kube-system meta.helm.sh/release-name=cilium
kubectl annotate rolebinding cilium-config-agent -n kube-system meta.helm.sh/release-namespace=kube-system
kubectl label rolebinding cilium-config-agent -n kube-system app.kubernetes.io/managed-by=Helm         
kubectl -n kube-system delete ds kube-proxy
kubectl -n kube-system delete cm kube-proxy
kubectl -n kube-system annotate service cilium-agent meta.helm.sh/release-name=cilium
kubectl -n kube-system annotate service cilium-agent meta.helm.sh/release-namespace=kube-system
kubectl -n kube-system label service cilium-agent app.kubernetes.io/managed-by=Helm 


#Apply Prometheus CRDs and Gateway API CRDs as pre-requisites
kubectl apply -f https://github.com/prometheus-operator/prometheus-operator/releases/download/v0.74.0/stripped-down-crds.yaml
kubectl apply -f https://raw.githubusercontent.com/prometheus-operator/prometheus-operator/main/example/prometheus-operator-crd/monitoring.coreos.com_servicemonitors.yaml
kubectl apply -f https://github.com/kubernetes-sigs/gateway-api/releases/download/v1.1.0/experimental-install.yaml

#Delete existing authentication path if it exists for the current cluster
curl $VAULT_URL_WITH_PORT/v1/sys/auth/$CLUSTER_NAME  \
--header 'X-Vault-Token: '"$VAULT_TOKEN"'' \
--request DELETE

#Create service account for Vault Secrets Operator Chicken-and-egg-situation
kubectl apply -f https://raw.githubusercontent.com/thecloudgarage/eks-anywhere/main/vso/vso-serviceaccount.yaml


#Retrieve Service account token to create Vault Role and Vault Auth config for Kubernetes authentication
kubectl get secret vault-auth --output='go-template={{ .data.token }}' | base64 --decode > client_token_review_jwt
kubectl config view --raw --minify --flatten --output='jsonpath={.clusters[].cluster.certificate-authority-data}' | base64 --decode > client_kube_ca_cert
kubectl config view --raw --minify --flatten --output='jsonpath={.clusters[].cluster.server}' > client_kube_host

TOKEN_REVIEW_JWT=$(cat client_token_review_jwt)
#Below step was key as the vault config post request expects \n in the cert value
KUBE_CA_CERT=$( awk 'NF {sub(/\r/, ""); printf "%s\\n",$0;}' client_kube_ca_cert)

#Enable Kubernetes Auth in Vault on a specific path with Cluster name 
KUBE_HOST=$(cat client_kube_host)
curl $VAULT_URL_WITH_PORT/v1/sys/auth/$CLUSTER_NAME  \
--header 'X-Vault-Token: '"$VAULT_TOKEN"'' \
--request POST \
--data @- << EOF
{
"type": "kubernetes"
}
EOF

#Create Kubernetes Auth config in Vault for the path with Cluster name
curl $VAULT_URL_WITH_PORT""/v1/auth/$CLUSTER_NAME/config --header 'X-Vault-Token: '"$VAULT_TOKEN"'' \
--request POST --data '{"token_reviewer_jwt": "'"$TOKEN_REVIEW_JWT"'", "kubernetes_host": "'"$KUBE_HOST"'", "kubernetes_ca_cert": "'"$KUBE_CA_CERT"'"}'


#Create Kubernetes Auth role in Vault and associate service account & policies
curl $VAULT_URL_WITH_PORT/v1/auth/$CLUSTER_NAME/role/vso-role \
--header 'X-Vault-Token: '"$VAULT_TOKEN"'' \
--request POST \
--data @- << EOF
{
"bound_service_account_names": "default",
"bound_service_account_namespaces": "*",
"policies": "site-a",
"ttl": "500h"
}
EOF

#Download Kustomizationcontrollertemplate for FLUX GitOps from Gitlab Ansible project and save it locally
curl -o kustomizationcontrollers.yaml  \
--header 'PRIVATE-TOKEN: '"$AWX_ANSIBLE_GITLAB_TOKEN"'' \
--url $GITLAB_URL_WITH_PORT/api/v4/projects/$AWX_ANSIBLE_GITLAB_PROJECT_ID/repository/files/kustomizationcontrollerstemplate.yaml/raw?ref=main

#Make changes to Kustomizationcontrollers file specific to the cluster
sed -i "s/clusterName/$CLUSTER_NAME/g" kustomizationcontrollers.yaml
sed -i "s/clusterId/$CLUSTER_ID/g" kustomizationcontrollers.yaml
#sed -i "s/ciliumHelmChartName/$CILIUM_HELM_CHART_NAME/g" kustomizationcontrollers.yaml
sed -i "s/ciliumHelmChartVersion/$CILIUM_HELM_CHART_VERSION/g" kustomizationcontrollers.yaml
sed -i "s/k8sApiIp/$K8S_API_IP/g" kustomizationcontrollers.yaml
sed -i "s|k8sPodCidr|$K8S_POD_CIDR|g" kustomizationcontrollers.yaml
#sed -i "s/PodCidrPrefix/$POD_CIDR_PREFIX/g" kustomizationcontrollers.yaml
sed -i "s|ciliumNativeRoutingCidr|$CILIUM_NATIVE_ROUTING_CIDR|g" kustomizationcontrollers.yaml
#sed -i "s/NativeRoutingCidrPrefix/$NATIVE_ROUTING_CIDR_PREFIX/g" kustomizationcontrollers.yaml
#
# NOTE USE OF | INSTEAD OF / AS SOME VARIABLES HAVE / IN THEIR VALUE 
sed -i "s|lbIpamPool|$LB_IPAM_POOL|g" kustomizationcontrollers.yaml
sed -i "s|peerAddress0|$PEER_ADDRESS_0|g" kustomizationcontrollers.yaml
sed -i "s/hubbleUiIngressHost/$HUBBLE_UI_INGRESS_HOST/g" kustomizationcontrollers.yaml
sed -i "s|prometheusRemoteWriteUrl|$PROMETHEUS_REMOTE_WRITE_URL|g" kustomizationcontrollers.yaml
#
#Upload/Commit the Kustomizationcontroller file to Flux-main project within the specific cluster sub-directory
curl -i -k --request POST \
     --header 'PRIVATE-TOKEN: '"$FLUX_MAIN_GITLAB_TOKEN"'' \
     --form "branch=main" \
     --form "commit_message=some commit message" \
     --form "start_branch=main" \
     --form "actions[][action]=create" \
     --form "actions[][file_path]=clusters/$CLUSTER_NAME/kustomizationcontrollers.yaml" \
     --form "actions[][content]=<kustomizationcontrollers.yaml" \
     --url $GITLAB_URL_WITH_PORT/api/v4/projects/$FLUX_MAIN_GITLAB_PROJECT_ID/repository/commits

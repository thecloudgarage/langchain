#!/bin/bash
rm -rf test-variables.txt
rm -rf curltest.txt
touch test-variables.txt
echo $HOME_DIRECTORY > variables-test.txt
echo $CLUSTER_BASE_DIRECTORY > variables-test.txt
echo $VAULT_URL_WITH_PORT > variables-test.txt
echo $VAULT_TOKEN > variables-test.txt
echo $GITLAB_URL_WITH_PORT > variables-test.txt
echo $AWX_ANSIBLE_GITLAB_PROJECT_ID > variables-test.txt
echo $AWX_ANSIBLE_GITLAB_TOKEN > variables-test.txt
echo $FLUX_MAIN_GITLAB_PROJECT_ID > variables-test.txt
echo $FLUX_MAIN_GITLAB_TOKEN > variables-test.txt
echo $CLUSTER_NAME > variables-test.txt
echo $CLUSTER_ID > variables-test.txt
echo $CILIUM_HELM_CHART_VERSION > variables-test.txt
echo $K8S_API_IP > variables-test.txt
echo $K8S_POD_CIDR={{ K8S_POD_CIDR }}
echo $CILIUM_NATIVE_ROUTING_CIDR={{ CILIUM_NATIVE_ROUTING_CIDR }}
echo $LB_IPAM_POOL > variables-test.txt
echo $PEER_ADDRESS_0 > variables-test.txt
echo $LOCAL_AS_NUMBER > variables-test.txt
echo $HUBBLE_UI_INGRESS_HOST > variables-test.txt
echo $PROMETHEUS_REMOTE_WRITE_URL > variables-test.txt
echo $KUBECONFIG > variables-test.txt
echo $(curl https://raw.githubusercontent.com/thecloudgarage/eks-anywhere/main/test.md) > variables-test.txt
echo $(kubectl get nodes) > variables-test.txt
echo $(eksctl anywhere version) > variables-test.txt
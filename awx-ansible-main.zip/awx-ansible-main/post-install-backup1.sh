#!/bin/bash
cd $HOME/$CLUSTER_NAME

curl https://vault1.poc.thecloudgarage.com:8200/v1/sys/auth/$CLUSTER_NAME  \
--header 'X-Vault-Token: '"$VAULT_TOKEN"'' \
--request DELETE

#Create service account for Vault Secrets Operator Chicken-and-egg-situation
kubectl apply -f https://raw.githubusercontent.com/thecloudgarage/eks-anywhere/main/vso/vso-serviceaccount.yaml

#Retrieve Service account token to create Vault Role and Vault Auth config for Kubernetes authentication
kubectl get secret vault-auth --output='go-template={{ .data.token }}' | base64 --decode > client_token_review_jwt
kubectl config view --raw --minify --flatten --output='jsonpath={.clusters[].cluster.certificate-authority-data}' | base64 --decode > client_kube_ca_cert
kubectl config view --raw --minify --flatten --output='jsonpath={.clusters[].cluster.server}' > client_kube_host

TOKEN_REVIEW_JWT=$(cat client_token_review_jwt)
#Below step was key as the vault config post request expects \n in the cert value
KUBE_CA_CERT=$( awk 'NF {sub(/\r/, ""); printf "%s\\n",$0;}' client_kube_ca_cert)

#Enable Kubernetes Auth in Vault on a specific path with Cluster name 
KUBE_HOST=$(cat client_kube_host)
curl https://vault1.poc.thecloudgarage.com:8200/v1/sys/auth/$CLUSTER_NAME  \
--header 'X-Vault-Token: '"$VAULT_TOKEN"'' \
--request POST \
--data @- << EOF
{
"type": "kubernetes"
}
EOF

#Create Kubernetes Auth config for the path with Cluster name
curl --header 'X-Vault-Token: '"$VAULT_TOKEN"'' \
--request POST --data '{"token_reviewer_jwt": "'"$TOKEN_REVIEW_JWT"'", "kubernetes_host": "'"$KUBE_HOST"'", "kubernetes_ca_cert": "'"$KUBE_CA_CERT"'"}' \
https://vault1.poc.thecloudgarage.com:8200/v1/auth/$CLUSTER_NAME/config

#Create Kubernetes Auth role and associate service account & policies
curl https://vault1.poc.thecloudgarage.com:8200/v1/auth/$CLUSTER_NAME/role/vso-role \
--header 'X-Vault-Token: '"$VAULT_TOKEN"'' \
--request POST \
--data @- << EOF
{
"bound_service_account_names": "default",
"bound_service_account_namespaces": "*",
"policies": "site-a",
"ttl": "500h"
}
EOF

#Download Kustomizationcontrollertemplate from Gitlab Ansible project and save it locally
curl -o kustomizationcontrollers.yaml  \
--header 'PRIVATE-TOKEN: '"$AWX_ANSIBLE_GITLAB_TOKEN"'' \
--url "https://gitlab1.poc.thecloudgarage.com:10443/api/v4/projects/"$AWX_ANSIBLE_GITLAB_PROJECT_ID"/repository/files/kustomizationcontrollerstemplate.yaml/raw?ref=main"

#Make changes to Kustomizationcontrollers file specific to the cluster
sed -i "s/clusterName/$CLUSTER_NAME/g" kustomizationcontrollers.yaml
sed -i "s/clusterId/$CLUSTER_ID/g" kustomizationcontrollers.yaml
sed -i "s/ciliumHelmChartName/$CILIUM_HELM_CHART_NAME/g" kustomizationcontrollers.yaml
sed -i "s/ciliumHelmChartVersion/$CILIUM_HELM_CHART_VERSION/g" kustomizationcontrollers.yaml
sed -i "s/k8sApiIp/$K8S_API_IP/g" kustomizationcontrollers.yaml
sed -i "s/k8sPodCidr/$K8S_POD_CIDR/g" kustomizationcontrollers.yaml
sed -i "s/ciliumNativeRoutingCidr/$CILIUM_NATIVE_ROUTING_CIDR/g" kustomizationcontrollers.yaml

#Upload/Commit the Kustomizationcontroller file to Flux-main project within the specific cluster sub-directory
curl -i -k --request POST \
     --header 'PRIVATE-TOKEN: '"$FLUX_MAIN_GITLAB_TOKEN"'' \
     --form "branch=main" \
     --form "commit_message=some commit message" \
     --form "start_branch=main" \
     --form "actions[][action]=create" \
     --form "actions[][file_path]=clusters/$CLUSTER_NAME/kustomizationcontrollers.yaml" \
     --form "actions[][content]=<kustomizationcontrollers.yaml" \
     --url "https://gitlab1.poc.thecloudgarage.com:10443/api/v4/projects/"$FLUX_MAIN_GITLAB_PROJECT_ID"/repository/commits"
